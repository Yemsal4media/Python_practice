import numpy as np

a0 = np.array([5, 6, 7, 8])
a1 = np.array([1, 2, 3, 4])

print("Array 0 (a0):")
print(a0)
print("Array 1 (a1):")
print(a1)
print("")

print("a0 + a1:")
print(a0 + a1)
print("")

print("a0 - a1:")
print(a0 - a1)
print("")

print("a0 * a1:")
print(a0 * a1)
print("")

print("a0 / a1:")
print(a0 / a1)
print("")

print("a0 ** a1:")
print(a0**a1)
print("")

print("a0 % a1:")
print(a0 % a1)
print("")
