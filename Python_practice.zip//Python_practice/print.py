#This is a testing program by Yemsal "yanky 5 mango serea 1 lima": Dt Cr8d: 150522
print('GOOD MORNING USER, Welcome to testing 101')
name = input('What is your name?\n  ')
name = str(name)
name = name.title()
print('Hello', name)
print("I am Glad to meet you", name)
age1 = input('How old are you?   ')
c = int(age1)
if c % 2 == 0:
    print('Your age is an even Number')
else:
    print('Your Age is a odd Number')
if c <= 10:
    print('Hello kiddo, are you sure you can handle this')
else:
    print('you are grown enough to handle this program')

a = 4
b = 5
m = (a + b + c)
m = float(m)
print((m**2)/4)
print(4/3)

