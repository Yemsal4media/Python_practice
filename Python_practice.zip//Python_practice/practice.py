    #Program to multiply so numbers 
print("Hello")
name= str(input ( "what is you name?",  )) 
name = name.upper()
print("Good day " , name, ", this program helps you add, subtract, multiply and find sum of square of two numbers ")
num1 =int(input ("Enter first number:   ")) 
num2 =int(input ("Enter second number:   ")) 
product = num1 * num2 
sum = num1 + num2  
differ =num1 - num2 
sumofsq = num1 + num2
print ("The sum ", num1, "+", num2, "is", sum) 
print ("The product ", num1, "x", num2, "is", product)
print ("The difference ", num1, "-", num2, "is", differ) 
print ("The sum of squares of", num1, "&", num2, "is", sumofsq) 