print ("welcome to my quiz")

playing = input("Do you want to play? ")
if playing != "yes":
    quit()

print("okay, thats all good :)")

