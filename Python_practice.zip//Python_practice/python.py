print ("welcome to my quiz")

playing = input()
