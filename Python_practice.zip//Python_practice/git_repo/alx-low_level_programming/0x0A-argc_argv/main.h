#ifndef MAIN_H
#define MAIN_H

int _putchar(char c);
__attribute__((unused));

#endif /* MAIN_H */
