I llove debugging
