This is the readme file for 0x0E-structures_typedef
