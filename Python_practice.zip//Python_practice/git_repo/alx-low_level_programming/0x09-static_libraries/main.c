#include "main.h"

/**
 * main - Entry check alx code
 *
 * Return: Always 0 (success)
*/

int main(void)
{
	_puts("\"At the end of the day, my goal was to be the best hacker\"\n\t- Kevin Mitnick");
	return (0);
}
