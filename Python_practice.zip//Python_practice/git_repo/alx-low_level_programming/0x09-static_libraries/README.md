This is the readme file for 0x09-static libraries
