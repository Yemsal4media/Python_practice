#include "main.h"

/**
 * atoi - this function converts a string
 *       into an integer
 *
 * @s: string input pointer
 *
 * Return: 0 if there is no number
*/

int _atoi(char *s)
{

}

