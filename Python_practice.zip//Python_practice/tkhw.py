from tkinter import Tk, Label

root = Tk()
Label(root, text="Hello, world!").pack()
root.mainloop()
